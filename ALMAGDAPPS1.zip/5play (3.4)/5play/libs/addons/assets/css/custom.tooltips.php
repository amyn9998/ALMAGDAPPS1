
<style>

.tooltip {
  display: inline-block;
}
.tooltip-point {
  display: inline-block;
  cursor: pointer;
  background: transparent;
  color: var(--rgba-color);
  position: relative;
  left: 4px;
}
.tooltip-content {
  display: inline-block;
  font-style: italic;
  margin-left: 1em;
  opacity: 0;
  transform: scale(0);
}
@keyframes in {
  from {
    opacity: 0;
    transform: scale(0);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
.tooltip:hover .tooltip-content {
  animation: in 1s ease-in forwards;
}
.form input[type="text"]:focus {
  outline-style: none;
}
.form input[type="text"]:focus + .tooltip .tooltip-content {
  animation: in 1s ease-in forwards;
}
</style>