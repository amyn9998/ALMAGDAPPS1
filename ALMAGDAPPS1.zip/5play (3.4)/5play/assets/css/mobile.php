<style id='mobile-css-<?php echo THEMES_NAMES; ?>-v<?php echo VERSION; ?>'>
@media (min-width: 320px) and (max-width: 1024px) {
	.page-head-main {margin-top: -4.5rem!important;}
} 
@media (min-width: 1025px) {
	.page-head-main {margin-top: 0!important;}
}
</style>
